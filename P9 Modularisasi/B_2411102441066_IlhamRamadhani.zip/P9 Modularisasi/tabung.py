pi = 3.14

def volume_tabung(r, t):
    return pi * (r**t) *t