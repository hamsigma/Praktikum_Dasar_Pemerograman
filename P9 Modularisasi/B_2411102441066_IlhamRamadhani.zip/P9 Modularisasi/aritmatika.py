def tambah (a, b):
    return a + b

def kurang (a, b):
    return a - b

def kali (a, b):
    return a * b

def bagi (a, b):
    return a / b

