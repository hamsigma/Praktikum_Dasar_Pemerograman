import math

def volumebalok(p,l,t):
    return p * l * t

def volumekubus(s):
    return s ** 3

def volumetabung(r,t):
    return math.pi * r**2 * t